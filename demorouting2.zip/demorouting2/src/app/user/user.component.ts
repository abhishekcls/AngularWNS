import { Component, OnDestroy, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit,OnDestroy {
  users:any;
  constructor(us:UserService) {
    us.getUsers().subscribe(u=>this.users=u);
   }
  ngOnDestroy(): void {
    console.log('ondestroy');
  }

  ngOnInit(): void {
    console.log('ngoninit')
  }

}
