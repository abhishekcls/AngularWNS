import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {

  id:number;
  user:any;
  constructor(ar:ActivatedRoute,private us:UserService,private r:Router) { 
    this.id= ar.snapshot.params.id;
    //this.id= ar.snapshot.params["id"];
  }

  ngOnInit(): void {
    this.us.getUserById(this.id).subscribe(u=>this.user=u);
  }

  back(){
    this.r.navigate(['/user']);
  }
}
