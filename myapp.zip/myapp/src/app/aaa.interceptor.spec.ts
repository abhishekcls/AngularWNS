import { TestBed } from '@angular/core/testing';

import { AaaInterceptor } from './aaa.interceptor';

describe('AaaInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AaaInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: AaaInterceptor = TestBed.inject(AaaInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
