import { Component, OnInit } from '@angular/core';
import { MyApiService } from '../myapi.service';

@Component({
  selector: 'app-callservice',
  templateUrl: './callservice.component.html',
  styleUrls: ['./callservice.component.css']
})
export class CallserviceComponent implements OnInit {
  data:any;
  constructor(myapi:MyApiService) {//DI
    myapi.getData().subscribe(d=>this.data=d);
  }

  ngOnInit(): void {
  }

}
