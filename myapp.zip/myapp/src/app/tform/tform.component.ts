import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tform',
  templateUrl: './tform.component.html',
  styleUrls: ['./tform.component.css']
})
export class TformComponent implements OnInit {
  name:string='Abhishek';
  constructor() { }
  formdata:any;
  ngOnInit(): void {
  }

  onSubmit(data:any){
    this.formdata=data;
    console.log(data);
  }
}
