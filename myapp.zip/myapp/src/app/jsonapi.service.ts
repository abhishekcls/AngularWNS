import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JsonapiService {

  constructor(private http:HttpClient) { }

  getEmps(){
    return this.http.get('http://localhost:3000/emp');
  }

  saveEmp(emp:any){
    return this.http.post('http://localhost:3000/emp',emp);
  }
}
