export class MyValidators{
    static empIdValidator(c:any){
        let id=c.value;
        if(!id)
          return null
        let min=101;
        let max=135;
        if(id>=min && id<=max)
          return null
        else
          return {'eid':{'min':min,'max':max}}
      }
}