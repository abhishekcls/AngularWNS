import { Component, Input, Output,EventEmitter } from "@angular/core";

@Component({
    selector:'nested',
    template:`<h2>Nested</h2>
    <table border="1">
    <tr [ngClass]="{'high':e.sal>=80000,'low':e.sal<80000}">
        <td>{{e.eid}}</td>
        <td>{{e.ename}}</td>
        <td>{{e.ename | slice:2}}</td>
        <td>{{e.ename | uppercase}}</td>
        <td>{{e.ename | lowercase}}</td>
        <td>{{e.gender | gender}}</td>
        <td>{{e.sal}}
        <span *ngIf="e.sal>=80000">*</span>
        <span *ngIf="checkSal(e.sal)">#</span>
        </td>
        <td>{{e.sal | number}}</td>
        <td>{{e.sal | currency}}</td>
        <td>{{e.sal | currency:'EUR'}}</td>
        <td>{{e.sal | currency:'INR'}}</td>
        <td>{{e.sal | tax | currency:'INR'}}</td>
        <td>{{e.sal | tax:0.2}}</td>
        <td>{{e.retired}}</td>
        <td>{{e.doj | date}}</td>
        <td>{{e.doj | date:'d/M/y'}}</td>
        <td>
        <img *ngIf="e.retired; else working" src="https://c.tenor.com/XrdpIPMSbEEAAAAC/emoji-laugh.gif" height="150" width="200">
        <ng-template #working>
            <img src="https://i.pinimg.com/originals/ff/f0/b3/fff0b38ccb8663c20ebb1b57c3e6940f.gif" height="150" width="200">
        </ng-template>
        </td>
        <td [ngSwitch]="e.gender">
        <span *ngSwitchCase="'M'">
        <img src="" height="150" width="200"/>
        Male
        </span>
        <span *ngSwitchCase="'F'">
        <img src="" height="150" width="200"/>
        Female
        </span>
        <span *ngSwitchDefault>Unknown</span>
        </td>
    </tr>
</table>
<button (click)="ctp()">ctp</button>
    `,
    styles:[`
    .high{
        color:red
    }
    .low{
        color:green
    }
    `]
})
export class NestedComponent{
    @Input() e:any;

    checkSal(sal:number):boolean{
        return sal>=80000;
    }

    @Output() 
    childevent=new EventEmitter;

    ctp(){
        this.childevent.emit(this.e.ename);
    }
}