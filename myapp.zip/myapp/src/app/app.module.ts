import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { AppComponent } from "./app.component";
import { NestedComponent } from "./nested.component";
import { AbcComponent } from './abc/abc.component';
import { XyzComponent } from './xyz/xyz.component';
import { DemoComponent } from './demo/demo.component';
import { GenderPipe } from "./gender.pipe";
import { TaxPipe } from './tax.pipe';
import { TformComponent } from './tform/tform.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RformComponent } from './rform/rform.component';
import {HttpClientModule} from '@angular/common/http';
import { CallserviceComponent } from './callservice/callservice.component';
import { MyApiService } from "./myapi.service";

@NgModule({
    declarations:[AppComponent,AnotherComponent,NestedComponent, AbcComponent, XyzComponent, DemoComponent,
    GenderPipe,
    TaxPipe,
    TformComponent,
    RformComponent,
    CallserviceComponent],
    imports:[BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule],
    bootstrap:[AppComponent,AnotherComponent],
    providers:[MyApiService]
})
export class AppModule{}