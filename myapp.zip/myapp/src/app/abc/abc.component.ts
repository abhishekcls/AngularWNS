import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abc',
  templateUrl: './abc.component.html',
  styleUrls: ['./abc.component.css']
})
export class AbcComponent implements OnInit {
  flag:boolean=false;

  basepath:string='https://hdsmileys.com/wp-content/uploads/2017/11/';
  path:string='https://hdsmileys.com/wp-content/uploads/2017/11/blush.gif'
  constructor() { }

  ngOnInit(): void {
  }
  show(){
    alert('hello');
  }
}
