import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MyValidators } from '../MyValidators';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
  emprform:FormGroup;
  constructor() { 
    this.emprform=new FormGroup({
      eid:new FormControl('',MyValidators.empIdValidator),
      ename:new FormControl('abc',Validators.compose([Validators.required, Validators.pattern('[a-zA-Z]+')]))
    });
  }
  setValue(){
    this.emprform.setValue({'eid':101,'ename':'Abhishek'});
  }
  patchValue(){
    this.emprform.patchValue({'ename':'Lalit'});
  }
  ngOnInit(): void {
  }
  onSubmit(data:any){
    console.log(data);
  }
}
