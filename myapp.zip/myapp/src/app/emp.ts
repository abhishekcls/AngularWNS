export class Emp{
    eid?:number;
    ename?:string;
}