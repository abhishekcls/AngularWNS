import { Component, OnInit } from '@angular/core';
import { JsonapiService } from '../jsonapi.service';

@Component({
  selector: 'app-demo',
  template: `
    <h1>My JSON API</h1>
    <table>
      <tr *ngFor="let e of emps">
        <td>{{e.id}}</td>
        <td>{{e.name}}</td>
      </tr>
    </table>
    <form #empform1="ngForm" (ngSubmit)="onSubmit(empform1.value)">
      <input type="text" name="id" placeholder="eid" ngModel required/><br/>
      <input type="text" name="name" placeholder="ename" ngModel/><br/>
      <input type="submit" [disabled]="empform1.invalid"/>
    </form>
  `,
  styles: [
  ]
})
export class DemoComponent implements OnInit {

  emps:any;
  constructor(private ja:JsonapiService) {
    ja.getEmps().subscribe(e=>this.emps=e);
   }

  ngOnInit(): void {
  }
  onSubmit(data:any){
    console.log(data);
    this.ja.saveEmp(data).subscribe(d=>{this.emps.push(d); alert(`inserted successfully!!!`)});
  }
}
