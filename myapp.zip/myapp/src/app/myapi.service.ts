import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class MyApiService{
    constructor(private http:HttpClient){//DI
    }

    getData(){
        return this.http.get('https://jsonplaceholder.typicode.com/posts');
    }
}