import { Component } from "@angular/core";
import { Emp } from "./emp";

@Component({
    selector:'app-root',
    templateUrl:`app.component.html`,
    styleUrls:[`app.component.css`]
})
export class AppComponent{
    name:string;
    cvalue:string='';
    games:string[]=['hockey','cricket','polo'];
    emp:Emp={'eid':101,'ename':'Ravi'};
    emps=[
        {'eid':1101,'ename':'Adarsh','gender':'M','sal':75000,'retired':false,'doj':new Date("1995-05-07")},
        {'eid':1102,'ename':'Simran','gender':'F','sal':55000,'retired':false,'doj':new Date("2005-04-08")},
        {'eid':1103,'ename':'Kavita','gender':'F','sal':89000,'retired':true,'doj':new Date("1991-07-04")},
        {'eid':1104,'ename':'Vikas','gender':'M','sal':45000,'retired':false,'doj':new Date("2013-09-11")},
        {'eid':1105,'ename':'Prateek','gender':'M','sal':95000,'retired':true,'doj':new Date("1981-02-01")}
    ]
    constructor(){
        this.name='Abhishek Samanta';
    }
}