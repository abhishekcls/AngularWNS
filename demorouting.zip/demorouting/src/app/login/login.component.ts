import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(data:any){
    if(data.user=='abc' && data.pass=='12345'){
      localStorage.setItem('user',data.user);
      alert('success');
    }
    else{
      alert('login failure');
    }
  }
  logout(){
    localStorage.removeItem('user');
  }
}
