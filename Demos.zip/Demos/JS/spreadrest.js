function add(...nums){//rest
    let sum=0;
    for(let n of nums){
        sum+=n;
        //console.log(n);
    }
    console.log(sum);
}

add(2,3);
add(1,4,5,7,8,9);

//copy
let arr1=[1,4,7];
let arr2=[...arr1]//spread//deep copy(value)
let arr3=arr1;//shallow copy(ref)
arr1[1]=9;
console.log(arr1);
console.log(arr2);
console.log(arr3);

add(...arr1);//spread
add(1,2,3,...arr1,...arr2);//spread

let emp={'eid':101,'ename':'Kavita'};
let emp2={...emp};//spread
//emp.eid=100;
console.log(emp);
console.log(emp2);

if(JSON.stringify(emp)===JSON.stringify(emp2)){
    console.log("same");
}
else
    console.log("not same");