class Parent{
    constructor(a){
        console.log("P Cons "+a);
    }
    disp(){
        console.log('Parent');
    }
}

class Child extends Parent{
    constructor(a,b){
        super(a);
        console.log("C Cons "+b);
    }
    disp(){
        super.disp();
        console.log('Child');
    }
}

let c=new Child(10,20);
c.disp();