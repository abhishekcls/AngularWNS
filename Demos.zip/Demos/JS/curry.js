function add(a){
    return function(b){
        console.log(a+b);
    }
}

var fx=add(1);
fx(2);
fx(3);
fx(4);

add(3)(4);