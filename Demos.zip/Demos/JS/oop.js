class Demo{
    name='Abhishek';
    constructor(name){
        this.name=name;
    }
    disp(){
        console.log(`Hi ${this.name}`);
    }
}

let obj=new Demo('Abhishek');
let obj2=new Demo('Naman');
obj.disp();

console.log(obj,typeof obj);
console.log(obj2,typeof obj2);