var a;//global

console.log(a);
console.log(typeof a);

a=100.5;

console.log(a);
console.log(typeof a);

a="abc";

console.log(a);
console.log(typeof a);

a=true;

console.log(a);
console.log(typeof a);