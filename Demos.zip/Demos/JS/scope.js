a=10;//global

function abc(){
    console.log(a);//
    //var a=20;
    if(true){
       var a=30;
        console.log(a);
    }
    console.log(a);//
}

console.log(a);
abc();