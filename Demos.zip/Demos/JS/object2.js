var emp={'eid':101,'ename':'Kavita'}

console.log(emp);
console.log(typeof emp);

var emp2=JSON.stringify(emp);
console.log(emp2);
console.log(typeof emp2);

var emp3=JSON.parse(emp2);
console.log(emp3);
console.log(typeof emp3);
