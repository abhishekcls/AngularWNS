var scores=[34,33,2,78,67];
console.log(scores);
/*
map => input 5 -> output 5
filter => input 5 -> output 0-5
reduce => summary -> 1
input 5 -> output 1
*/

var r=scores.map(v=>v+1);

console.log(r);

//Task
//Even Numbers

var evens = scores.filter(item=>item%2 ===0)

console.log(evens)

//Task
//sum
var sum =scores.reduce((acc, cur)=>acc + cur,0)
console.log(sum)