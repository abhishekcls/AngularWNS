function print(h){
    console.log(`${this.ename} likes to ${h}`)
}
const emp={
    'eid':101,
    'ename':'Abhishek',
    'hobbies':['read','write','play'],
    'details':function(){
        console.log(`Details of ${this.eid}`);
       /*for(let h of this.hobbies){
            console.log(`${this.ename} likes to ${h}`)
        }*/
        /*this.hobbies.forEach(print,this)*/
        this.hobbies.forEach(h=>console.log(`${this.ename} likes to ${h}`));
    }
}

console.log(emp)
emp.details();