let arr=[1,5,7,8,3];
/*
let a=arr[0];
let b=arr[1];
*/

let [a,b,...c]=arr;
console.log(a,b,c);

let emp={'eid':101,'ename':'Kavita','sal':55000};
let {eid,...others}=emp;//rest
console.log(eid,others);