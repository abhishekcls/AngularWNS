//JSON -> JavaScript Object Notation

//{property:value}
//{property1:value1,property2:value2}

var emp={'eid':101,'ename':'Kavita'}

console.log(emp);
console.log(typeof emp);
console.log(Array.isArray(emp));

console.log(emp.eid,emp.ename);
console.log(emp["eid"],emp["ename"]);//recommended

for(e in emp){
    console.log(e,emp[e]);
}