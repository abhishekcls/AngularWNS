var fruits=['apple','banana','kiwi'];

console.log(fruits);
console.log(typeof fruits);

console.log("=====for=====");
for(var i=0;i<fruits.length;i++){
    console.log(fruits[i]);
}

console.log("=====while=====");
var i=0;
while(i<fruits.length){
    console.log(fruits[i++]);
}

console.log("=====do..while=====");
var i=0;
do{
    console.log(fruits[i++]);
}while(i<fruits.length);

console.log("=====for..in=====");
for(var i in fruits){
    console.log(i,fruits[i]);
}

var fruits=['apple','banana','kiwi'];

console.log(fruits);
console.log(typeof fruits);

console.log("=====for=====");
for(var i=0;i<fruits.length;i++){
    console.log(fruits[i]);
}

console.log("=====while=====");
var i=0;
while(i<fruits.length){
    console.log(fruits[i++]);
}

console.log("=====do..while=====");
var i=0;
do{
    console.log(fruits[i++]);
}while(i<fruits.length);

console.log("=====forEach=====");

function show(v,i,arr){
    console.log(i,v,arr);
}

fruits.forEach(show);

console.log("=====forEach 2=====");

fruits.forEach(function(v){
    console.log(v);
});

console.log("=====forEach 3=====");

fruits.forEach(v=>console.log(v));
console.log(Array.isArray(fruits));