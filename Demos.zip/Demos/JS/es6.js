let a=100;
console.log(a,typeof a);

function abc(){
    //console.log(b);//error
    let b=200;
    console.log(b);
    if(true){
        let c=300;
        c=400;
        console.log(c);
    }
   //console.log(c);//error
}

abc();