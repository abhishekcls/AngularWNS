function add(a,b,c=0){
    console.log("a=",a,"b=",b,"c=",c);
    console.log(a+b+c);
}

add(2,3);//5
add(2,3,4);//9
add(1,2,3,4);//6