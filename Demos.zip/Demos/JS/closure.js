var a=10;//global
function outer(){
    var b=20;//closure
    console.log(a,b);
    return function(){
        var c=30;//function
        console.log(a,b,c);
    }
}

console.log(a);
var fx=outer();
fx();

var obj=new outer();//es5