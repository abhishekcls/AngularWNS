//1
/*function abc(){
    console.log("hello");
}

abc();*/

//2
/*abc=function(){
    console.log("hello");
}

abc();
console.log(typeof abc);
*/

//3
//IIFE -> Immediately Invoked Function Expressions
(function(){
    console.log("hello");
})()
