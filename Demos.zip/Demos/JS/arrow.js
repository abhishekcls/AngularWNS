abc=name=>console.log(`hello ${name}`);

abc('Abhishek');

square=n=>n*n;

console.log(square(5));