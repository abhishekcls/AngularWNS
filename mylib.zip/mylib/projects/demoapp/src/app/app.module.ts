import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DemolibModule} from 'demolib';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    DemolibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
