import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-demolib',
  template: `
    <button (click)="show()">lib demo</button>
  `,
  styles: [
  ]
})
export class DemolibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  show(){
    alert('Hello from library');
  }
}
