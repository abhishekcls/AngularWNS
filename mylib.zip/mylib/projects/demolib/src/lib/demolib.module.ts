import { NgModule } from '@angular/core';
import { DemolibComponent } from './demolib.component';



@NgModule({
  declarations: [
    DemolibComponent
  ],
  imports: [
  ],
  exports: [
    DemolibComponent
  ]
})
export class DemolibModule { }
