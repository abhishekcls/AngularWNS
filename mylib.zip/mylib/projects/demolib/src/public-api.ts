/*
 * Public API Surface of demolib
 */

export * from './lib/demolib.service';
export * from './lib/demolib.component';
export * from './lib/demolib.module';
